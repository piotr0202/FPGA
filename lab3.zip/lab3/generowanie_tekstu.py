import random

# Tworzymy 16 losowych znaków ASCII
data = ''.join(random.choices("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", k=16))

# Zapisujemy do pliku binarnego
with open("input_file.bin", "wb") as f:
    f.write(data.encode())

print("Plik input_file.bin został wygenerowany!")
